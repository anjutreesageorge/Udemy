package repository;

import java.util.logging.Logger;

import org.junit.Test;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import repository.CourseRepository;

public class CourseRepositoryTest {
	
	@Autowired
	CourseRepository cr;
	private Logger logger =(Logger) LoggerFactory.getLogger(this.getClass());
	
	@Test
	public void findAll_1()
	{
	cr.findById(1000L);
	}

}
